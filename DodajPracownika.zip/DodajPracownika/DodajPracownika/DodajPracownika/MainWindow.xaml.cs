﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DodajPracownika
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string wygenerowane_haslo = "";

       
        public MainWindow()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string litery_male = "asdfghjklzxcvbnmqwertyuiop";
            string litery_duze = "ASDFGHJKLZXCVBNMQWERTYUIOP";
            string cyfryr = "1234567890";
            string znaki = "!@#$%^&*()_+=-][{}><.,/?";

            int dlugosc = int.Parse(tablicaznak.Text);

            int indeks = 0;

            char[] haslo = new char[dlugosc];

            Random rnd = new Random();  // stworzenie obiektu typu random

            if (malewielkie.IsChecked == true && indeks < dlugosc)
            {
                haslo[indeks] = litery_duze[rnd.Next(litery_duze.Length)];
                indeks++;
            }
            if (cyfry.IsChecked == true && indeks < dlugosc)
            {
                haslo[indeks] = cyfryr[rnd.Next(cyfryr.Length)];
                indeks++;
            }
            if (znakispec.IsChecked == true && indeks < dlugosc)
            {
                haslo[indeks] = znaki[rnd.Next(znaki.Length)];
                indeks++;
            }

            for(int i = indeks; i < dlugosc; i++)
            {
                haslo[i] = litery_male[rnd.Next(litery_male.Length)];
            }

            wygenerowane_haslo = new string(haslo);

            MessageBox.Show(wygenerowane_haslo, "wygenerowane hasło");


        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            string imie = imietxt.Text;
            string nazwisko = nazwiskotxt.Text;
            string stanowisko = stanowiskocomb.Text;

            MessageBox.Show(  imie + " " + nazwisko + " " + stanowisko + " " + wygenerowane_haslo,"Dane pracownika: ");





        }
    }
}